<div class="widget mod <?= $widget->slug ?>">
	<h5 class="hd"><?= $widget->instance_title; ?></h5>
	<div class="bd">
	<?= $widget->body; ?>
	</div>
</div>